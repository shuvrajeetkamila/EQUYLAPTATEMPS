# Synthetic surgery checkpoint — NOT a pretrained capability model

This artifact uses tiny RANDOM Mamba and Qwen2 parents. Only new dense surgical
seams were calibrated on eight hand-authored arithmetic-format prompts.
No real-world math/reasoning/code ability or benchmark improvement is claimed.

Install the exact source:

    python -m pip install "git+https://github.com/shuvrajeetkamila/EQUYLAPTATEMPS.git@fba0fad4129f96909a0cb35841fc6b214f62517e"

Then, from this extracted directory:

    equylaptatemps inspect child --verify
    equylaptatemps generate --child child --prompt "1+1=" --max-new-tokens 8

Expect nonsensical byte-level text, not a valid arithmetic answer. The point is
whole-block heterogeneous execution, unchanged parent tensors, and portable
reload. See docs/model-card.md and reports/synthetic-smoke.json for limitations.
The source pipeline supports separate real-parent experiments; no pretrained
weights are included here. Software/this synthetic artifact: Apache-2.0.
Dependencies and any future real parent weights retain their own licenses.
